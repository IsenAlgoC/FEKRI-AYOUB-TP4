#include <stdio.h>
#include <stdlib.h>


/*
* Ce programme demande un nom un pr�nom et un sexe � l'utilisateur
* et les affiche sous la forme Madame x ou Monsieur y
*/
int main() {
	char nom[20];
	char prenom[20];
	char sexe;
	printf("Quel est votre nom?\n");
	scanf_s("%s", nom);
	printf("Quel est votre prenom?\n");
	scanf_s("%s", prenom);
	printf("Quel est votre sexe (H/F)?\n");
	sexe = _getch();
	if (sexe == 'H') {
		printf("Monsieur %s %s\n", prenom, nom);
	}
	else {
		if (sexe == 'F') {
			printf("Madame %s %s\n", prenom, nom);
		}
		else {
			printf("Votre r�ponse n'est pas valide! \n");
			printf("Quel est votre sexe (H/F)?\n");
			sexe = _getch();
		}
	}

	return(EXIT_SUCCESS);
}