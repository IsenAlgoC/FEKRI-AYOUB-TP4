#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	char mot[50];
	/*
	* Demander � l'utilisateur d'entrer le mot
	*/
	printf("Veuillez saisir le mot\n");
	scanf_s("%s", mot);
	int length = strlen(mot);
	/*
	* Verifier si mot est un palindrome
	*/
	int indice_debut = 0;
	int indice_fin = length-1;
	while (indice_debut < indice_fin) {
		if (mot[indice_debut] != mot[indice_fin]) {
			printf("%s n'est pas un palindrome\n", mot);
			return 0;
		}
		indice_debut++;
		indice_fin--;
	}
	printf("%s est un palindrome\n", mot);
	return(EXIT_SUCCESS);
}