#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void main() {
	/*
	* Declaration des variables auquelles on aura besoin
	*/
	int* Curseur=NULL;
	int Val;
	int trouvee = 0;
	int pos_curseur = 0;
	srand(time(NULL));
	int tableau[100];
	/*
	* initialisation
	*/
	for (int i = 0; i < 100; i++) {
		tableau[i] = rand();
	}
	tableau[50] = 50;
	tableau[20] = 50;
	tableau[1] = 50;
	/*
	* Demander la valeur � l'utilisateur 
	*/
	printf("Entrer la valeur recherchee: ");
	scanf("%d", &Val);
	printf("%d\n", Val);
	//Commencer la recherche
	Curseur = &tableau[0];
	while (Curseur != &tableau[99]) {
		if (!trouvee) {
			if (*Curseur == Val) {
				printf("La valeur %d a ete trouve en %d ", Val, pos_curseur);
				trouvee = 1;
			}
			Curseur++;
			pos_curseur++;
		}
		else {
			if (*Curseur == Val) {
				printf("puis en %d ", pos_curseur);
				trouvee = 1;
			}
			Curseur++;
			pos_curseur++;
		}
	}
	if (trouvee) {
		printf(".\n");
	}
	else {
		printf("%d n'est pas dans le tableau\n", Val);
	}
}
