#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	int nbr_mot = 1;
	int somme_longueur = 0;
	char buffer[1024];
	/*
	* Demander la phrase
	*/
	printf("Entrez votre phrase\n");
	gets_s(buffer, 1024);
	int legnth = strlen(buffer);
	for (int i = 0; i < legnth; i++) {
		if (buffer[i] == ' ') {
			nbr_mot++;
		}
		else {
			somme_longueur++;
		}
	}
	float moyenne = somme_longueur / nbr_mot;
	printf("La phrase contient %d mot, avec une longueur moyenne %.2f\n", nbr_mot, moyenne);

	return(EXIT_SUCCESS);
}