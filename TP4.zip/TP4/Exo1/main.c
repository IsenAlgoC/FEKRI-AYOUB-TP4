/*
* Biblioth�ques standards de c
*/
#include <stdio.h>
#include <stdlib.h>

/*
* Fichiers ent�te
*/
#include "exo1.h"

/*
* Une fonction qui permet d'afficher une heure 
*/
void afficher_heure(HEURE h) {
	printf("%d:%d\n", h.heure, h.minute);
}


int main() {
	//HEURE : HeureDebut, HeureFin, Duree.
	//HeureDebut vaut 12h30, Duree vaut 00 :45.
	HEURE HeureDebut = {12 , 30};
	HEURE Duree = { 0 , 45 };
	HEURE HeureFin;
	HeureFin.heure = HeureDebut.heure + Duree.heure;
	HeureFin.minute = HeureDebut.minute + Duree.minute;
	if (HeureFin.minute >= 60) {
		int nbr_heure = HeureFin.minute / 60;
		HeureFin.heure += nbr_heure;
		HeureFin.minute -= nbr_heure * 60;
	}
	printf("HeureDebut: ");
	afficher_heure(HeureDebut);
	printf("HeureFin: ");
	afficher_heure(HeureFin);
	printf("Duree: ");
	afficher_heure(Duree);
	return(EXIT_SUCCESS);
}