/*
* Ent�te permettant de ne pas inclure deux fois le m�me header
*/
#ifndef TP_4
#define TP_4

typedef struct heure { 
	int heure; 
	int minute; 
}HEURE;


#endif // !TP_4
