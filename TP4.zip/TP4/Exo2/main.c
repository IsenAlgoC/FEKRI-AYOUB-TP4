#include <stdio.h>
#include <stdlib.h>

#define SEPARATEUR '/'
#define TAILLETAB1 20

int main() {
	/*
	* D�claration du tableau
	*/
	int MyTab1[TAILLETAB1];
	/*
	* Remplissage et affichage du contenu du tableau
	*/
	for (int i = 0; i < 20; i++) {
		MyTab1[i] = i + 1;
		printf("%d%c", MyTab1[i], SEPARATEUR);
	}
	printf("\nFin du premier affichage\n");
	int* MyPtr = &MyTab1[19];
	for (int i = 19; i >= 0 ; i--) {
		printf("%d%c", *MyPtr, SEPARATEUR);
		MyPtr = MyPtr - 1;
	}
	printf("\nFin du second affichage\n");
	return(EXIT_SUCCESS);
}